using UnityEngine;

public class MouseLook : MonoBehaviour
{

}
